#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <semaphore.h>
#include <signal.h>
#include "projet.h"

void
main ()
{
  quai.nbquai = 2;
  quai.stat[0] = 0;
  quai.stat[1] = 0;
  pthread_t thrPeniche[23];
  int i, rc, j;
  system ("clear");
  printf("\n                                      ####################################");
  printf("\n                                      ### SIMULATION PLATEFORME DELTA 3###");
  printf("\n                                      ####################################");
  printf ("\n                                          1- Déchargement Péniche");
  printf ("\n                                           2-Chargement Péniche");
  printf ("\n                                              Votre choix: ");
  scanf ("%d", &rep);
  initialisation_semaphores ();
  signal (SIGINT, traitantSIGINT);
  usleep (1000000);
  switch (rep)
    {
    case 1:
      {
	initialisation_donnees_dechargement ();
	break;
      }
    case 2:
      {
	initialisation_donnees_chargement ();
      }

    }
  for (i = 0; i < 23; i++)
    {

      if (rc = pthread_create (&thrPeniche[i], 0, ammarrer, (void *) i) != 0)
	erreur ("Erreur Creation thread");
    }
  for (i = 0; i < 23; i++)
    {

      pthread_join (thrPeniche[i], NULL);
    }
  affichage;
  destruction_semaphores ();
}
