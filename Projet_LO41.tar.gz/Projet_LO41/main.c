#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <semaphore.h>
#include <signal.h>
#include "projet.h"

void
main ()
{
  quai.nbquai = 2;
  quai.stat[0] = 0;
  quai.stat[1] = 0;
  pthread_t thrPeniche[23];
  int i, rc, j;
  system("clear");
  printf("\n1- Déchargement Péniche");
  printf("\n2-Chargement Péniche");
  printf("\nVotre choix: ");
  scanf("%d",&rep);
  //initialisation_donnees ();
  initialisation_semaphores ();
  signal(SIGINT,traitantSIGINT);
   signal(SIGTSTP,traitantSIGTSTP);
  usleep (1000000);
  switch(rep)
  {
	case 1:
	{ 
		initialisation_donnees_dechargement ();
		break;
	}
	case 2:
	{
		initialisation_donnees_chargement ();
	}

 }
  for (i = 0; i < 23; i++)
    {

      if (rc = pthread_create (&thrPeniche[i], 0, ammarrer, (void *) i) != 0)
	erreur ("Erreur Creation thread");
//              pthread_join(thrPeniche[i],NULL);
      //usleep(30000); 
    }
  for (i = 0; i < 23; i++)
    {

      pthread_join (thrPeniche[i], NULL);
    }
  //pthread_exit(NULL);
   affichage;
  destruction_semaphores ();
}
