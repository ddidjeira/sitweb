#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <semaphore.h>
#include <signal.h>
#include "projet.h"

// Définition des couleurs

#define red   "\033[0;31m"
#define cyan  "\033[0;36m"
#define green "\033[0;32m"
#define blue  "\033[0;34m"
#define black  "\033[0;30m"
#define brown  "\033[0;33m"
#define magenta  "\033[0;35m"
#define gray  "\033[0;37m"
#define none   "\033[0m"

void erreur(const char *msg)
{
    perror(msg);
    exit(1);
}

sem_t mutexAccesQuai, mutexLiberationQuai;

pthread_cond_t condition1 = PTHREAD_COND_INITIALIZER;	/* Création de la condition */
pthread_cond_t condition2 = PTHREAD_COND_INITIALIZER;    /* Création de la condition */
pthread_mutex_t mutexAccesNbcamions = PTHREAD_MUTEX_INITIALIZER;	/* Création du mutex */

//Fonction pour compter les camions
int comptercam (listecamions L)
{
  int nb = 0;
  listecamions P;
  P = L;
  if (P != NULL)
    {
      while (P != NULL)
	{
	  nb++;
	  P = P->next;
	}
    }
  return nb;
}

//Fonction permettant d'ajouter un camion à la liste de camions
listecamions ajouter (listecamions L, camion elt)
{
  listecamions P, nouveau;
  P = L;
  nouveau = (element *) malloc (sizeof (element));
  nouveau->c = elt;
  if (P == NULL)
    {
      return nouveau;
    }
  else
    {
      while (P->next != NULL)
	{
	  P = P->next;
	}
      P->next = nouveau;
      nouveau->next = NULL;
      return L;
    }
}

//traitant SIGINT
void traitantSIGINT(int num) {
  	if (num != SIGINT)
    	perror("Probleme sur SIGINT...");
    printf("\t\n");
    destruction_semaphores();
    exit(EXIT_SUCCESS);
}
//traitant SIGINT
void traitantSIGTSTP(int num) {
        if (num != SIGTSTP)
        perror("Probleme sur SIGTSTP...");
  L1=NULL;
  L2=NULL;
  if(rep==1)
  {
  initialisation_train2 ("train2");
  initialisation_train1 ("train1");
  L1 = initialisation_camions (L1, "camions1");
  L2 = initialisation_camions (L2, "camions2");
  }
  else
  {
    initialisation_train2 ("Ctrain2");
  initialisation_train1 ("Ctrain1");
  L1 = initialisation_camions (L1, "Ccamions1");
  L2 = initialisation_camions (L2, "Ccamions2"); 
  }
  nbcamions1 = comptercam (L1);
  nbcamions2 = comptercam (L2);
  pthread_cond_signal(&condition1);
   pthread_cond_signal(&condition2);
}


//DEBUT INITIALISATION PENICHE
int initialisation_peniches (char *penicheFileName)
{
  FILE *pFile;
  char *line = NULL;
  size_t len = 0;
  int nbpeniches = 0;
  if (penicheFileName)
    {
      pFile = fopen (penicheFileName, "r");
      if (pFile)
	{
	  while ((getline (&line, &len, pFile) != EOF)
		 && (&Tpeniche[nbpeniches]))
	    {
	      sscanf (line, "%d,%d,%d", &Tpeniche[nbpeniches].ID,
		      &(Tpeniche[nbpeniches]).place[0],
		      &(Tpeniche[nbpeniches]).place[1],
			&Tpeniche[nbpeniches].charger);
	      nbpeniches++;
	    }
	}
      else
	{
	  perror ("Erreur ouverture fichier peniches");
	}
    }
  fclose (pFile);
  return nbpeniches;
}

//DEBUT INITIALISATION CAMION
listecamions initialisation_camions (listecamions L, char *camionFileName)
{
  FILE *pFile;
  char *line = NULL;
  size_t len = 0;
  camion cam;
  int nbcamions = 0;
  if (camionFileName)
    {
      pFile = fopen (camionFileName, "r");
      if (pFile)
	{
	  while ((getline (&line, &len, pFile) != EOF))
	    {
	      sscanf (line, "%d,%d", &cam.ID, &cam.libre);
	      L = ajouter (L, cam);
	    }
	}
      else
	{
	  perror ("Erreur ouverture fichier peniches");
	}
    }
  fclose (pFile);
  return L;
}

//INITIALISATION TRAIN
void initialisation_train1 (char *train1FileName)
{
  FILE *pFile;
  char *line = NULL;
  size_t len = 0;
  int nbtrains = 0;
  if (train1FileName)
    {
      pFile = fopen (train1FileName, "r");
      if (pFile)
	{
	  while ((getline (&line, &len, pFile) != EOF) && (&Ttrain[0]))
	    {
	      sscanf (line, "%d,%d,%d,%d,%d,%d,%d,%d", &Ttrain[nbtrains].ID,
		      &(Ttrain[0]).wagon[0],
		      &(Ttrain[0]).wagon[1],
		      &(Ttrain[0]).wagon[2],
		      &(Ttrain[0]).wagon[3],
		      &(Ttrain[0]).wagon[4],
		      &(Ttrain[0]).wagon[5], &Ttrain[0].dispo);
	      nbtrains++;
	    }
	}
      else
	{
	  perror ("Erreur ouverture fichier trains");
	}
    }
  fclose (pFile);
}
void initialisation_train2 (char *train2FileName)
{
  FILE *pFile;
  char *line = NULL;
  size_t len = 0;
  int nbtrains = 0;
  if (train2FileName)
    {
      pFile = fopen (train2FileName, "r");
      if (pFile)
        {
          while ((getline (&line, &len, pFile) != EOF) && (&Ttrain[1]))
            {
              sscanf (line, "%d,%d,%d,%d,%d,%d,%d,%d", &Ttrain[1].ID,
                      &(Ttrain[1]).wagon[0],
                      &(Ttrain[1]).wagon[1],
                      &(Ttrain[1]).wagon[2],
                      &(Ttrain[1]).wagon[3],
                      &(Ttrain[1]).wagon[4],
                      &(Ttrain[1]).wagon[5], &Ttrain[1].dispo);
              nbtrains++;
            }
        }
      else
        {
          perror ("Erreur ouverture fichier trains");
        }
    }
  fclose (pFile);
}


//INITIALISATION DES DONNEES;
void initialisation_donnees_dechargement ()
{
  initialisation_peniches ("peniches");
  initialisation_train2 ("train2");
  initialisation_train1 ("train1");
  L1 = initialisation_camions (L1, "camions1");
  L2 = initialisation_camions (L2, "camions2");
  nbcamions1 = comptercam (L1);
  nbcamions2 = comptercam (L2);
}

void initialisation_donnees_chargement ()
{
  initialisation_peniches ("Cpeniches");
  initialisation_train2 ("Ctrain2");
  initialisation_train1 ("Ctrain1");
  L1 = initialisation_camions (L1, "Ccamions1");
  L2 = initialisation_camions (L2, "Ccamions2");
  nbcamions1 = comptercam (L1);
  nbcamions2 = comptercam (L2);
}


//INITIALISATION DES SEMAPHORES

void initialisation_semaphores ()
{
  printf ("\t%sInitialisation semaphores...\n", brown);
  if (sem_init (&mutexAccesQuai, 0, 1) == -1)
    perror ("Erreur initialisation mutexAccesQuai");
  if (sem_init (&mutexLiberationQuai, 0, 0) == -1)
    perror ("Erreur initialisation mutexLiberationQuai");
}

//FIN

//DESTRUCTION DES SEMAPHORES

void destruction_semaphores ()
{
  printf ("\t%sDestruction semaphores...\n", brown);
  if (sem_destroy (&mutexAccesQuai) == -1)
    perror ("Erreur destruction mutexAccesQuai");
  if (sem_destroy (&mutexLiberationQuai) == -1)
    perror ("Erreur destruction mutexLiberationQuai");
  printf ("%s\n", none);
}

//FIN

//FONCTION DE DECHARGEMENT DE LA PENICHE SUR LE TRAIN

void dechargement_peniche_train (chargement_train c)
{
  int i, j, nb;
  for (i = 0; i < 2; i++)
    {
      j = 0;
      while ((Tpeniche[c.numpeniche]).place[i] == 1 && j <6)
	{
	  if((Ttrain[c.numtrain]).wagon[j]==0)
	  {
	    (Ttrain[c.numtrain]).wagon[j] = 1;
	    (Tpeniche[c.numpeniche]).place[i] = 0;
	  }
	  j++;
	}
    }
  nb = 0;
  for (j = 0; j < 6; j++)
    {
      if ((Ttrain[c.numtrain]).wagon[j])
	nb++;
    }
  if (nb == 6)
    (Ttrain[c.numtrain]).dispo = 0;
}

//FIN
void chargement_train_peniche (chargement_train c)
{
  int i, j, nb;
  for (i = 0; i < 2; i++)
    {
      j = 0;
      while ((Tpeniche[c.numpeniche]).place[i] == 0 && j <6)
        {
          if((Ttrain[c.numtrain]).wagon[j]==1)
          {
            (Ttrain[c.numtrain]).wagon[j] = 0;
            (Tpeniche[c.numpeniche]).place[i] = 1;
          }
          j++;
        }
    }
  nb = 0;
  for (j = 0; j < 6; j++)
    {
      if (!(Ttrain[c.numtrain]).wagon[j])
        nb++;
    }
  if (nb == 6)
    (Ttrain[c.numtrain]).dispo = 1;
}

//FIN

//FONCTION DU DECHARGEMENT DE LA PENICHE SUR LE CAMION

void dechargement_peniche_camion (chargement_camion cam)
{
  int i;
  if (cam.numliste == 1)
    {
      for (i = 0; i < 2; i++)
	{
	  pthread_mutex_lock (&mutexAccesNbcamions);
	  if (nbcamions1 == 0)
	    {
	      while (nbcamions1 == 0)
		{
		  pthread_cond_wait (&condition1, &mutexAccesNbcamions);	/* On attend que la condition soit remplie */
		}
	    }
	  pthread_mutex_unlock (&mutexAccesNbcamions);
	  if ((Tpeniche[cam.numpeniche]).place[i] == 1)
	    {
	      (Tpeniche[cam.numpeniche]).place[i] = 0;
	      (L1->c).libre = 1;
	    }
	  L1 = L1->next;
	  nbcamions1--;
	}
    }
  else
    {
      for (i = 0; i < 2; i++)
	{
	  pthread_mutex_lock (&mutexAccesNbcamions);
	  if (nbcamions2 == 0)
	    {
	      while (nbcamions2 == 0)
		{
		  pthread_cond_wait (&condition2, &mutexAccesNbcamions);	/* On attend que la condition soit remplie */
		}
	    }
	  pthread_mutex_unlock (&mutexAccesNbcamions);
	  if ((Tpeniche[cam.numpeniche]).place[i] == 1)
	    {
	      (Tpeniche[cam.numpeniche]).place[i] = 0;
	      (L2->c).libre = 1;
	    }
	  nbcamions2--;
	  L2 = L2->next;
	}
    }
}

//FIN

//FONCTION DU DECHARGEMENT DE LA PENICHE SUR LE CAMION

void chargement_camion_peniche (chargement_camion cam)
{
  int i;
  if (cam.numliste == 1)
    {
      for (i = 0; i < 2; i++)
        {
          pthread_mutex_lock (&mutexAccesNbcamions);
          if (nbcamions1 == 0)
            {
              while (nbcamions1 == 0)
                {
                  pthread_cond_wait (&condition1, &mutexAccesNbcamions);        /* On attend que la condition soit remplie */
                }
            }
          pthread_mutex_unlock (&mutexAccesNbcamions);
          if ((Tpeniche[cam.numpeniche]).place[i] == 0)
            {
              (Tpeniche[cam.numpeniche]).place[i] = 1;
              (L1->c).libre = 0;
            }
          L1 = L1->next;
          nbcamions1--;
        }
    }
  else
    {
      for (i = 0; i < 2; i++)
        {
          pthread_mutex_lock (&mutexAccesNbcamions);
          if (nbcamions2 == 0)
            {
              while (nbcamions2 == 0)
                {
                  pthread_cond_wait (&condition2, &mutexAccesNbcamions);        /* On attend que la condition soit remplie */
                }
            }
          pthread_mutex_unlock (&mutexAccesNbcamions);
          if ((Tpeniche[cam.numpeniche]).place[i] == 0)
            {
              (Tpeniche[cam.numpeniche]).place[i] = 1;
              (L2->c).libre = 0;
            }
          nbcamions2--;
          L2 = L2->next;
        }
    }
}

//FIN

//FONCTION DU THREAD PENICHE

void * ammarrer (void *data)
{
  int id;
  id = (int) data;
  chargement_train c;
  chargement_camion cam;
  cam.numpeniche = id;
  c.numpeniche = id;
  while (1)
    {
      if(rep==1)
	{
      //Verifier qu 'au moins un des quais est disponible
      sem_wait (&mutexAccesQuai);
      //attente signal acces quai
	affichage();
      printf
	("\nVerification disponibilite d'un quai avec la peniche ...%d\n",id);
	usleep (1000000);
      if (quai.nbquai == 0)
	{
	  sem_post (&mutexAccesQuai);	//emission signal acces quai
		affichage();
	  printf
	    ("\nAucun quai disponible, attente disponibilite avec la peniche %d...\n",
	     id);
	 usleep (1000000);
	  sem_wait (&mutexLiberationQuai);	//attente signal liberation quai
	}
      else
	{
	  quai.nbquai--;
	  if (!quai.stat[0])	//on est au quai 1
	    {
	    affichage();
	    printf ("\nOccupation du quai n°1 avec la peniche %d...\n", id);
	    usleep (1000000);
	      quai.stat[0] = 1;	// on met le booléen du quai 1 à occupé
	      sem_post (&mutexAccesQuai);	//emission signal acces quai
	      usleep(1000000);
	      c.numtrain = 0;
	      if (Ttrain[0].dispo)
		{
		  dechargement_peniche_train (c);
		}
	      else
		{
		  pthread_mutex_lock (&mutexAccesNbcamions);
		  if (nbcamions1 == 0)
		    {
		     while (nbcamions1 == 0)
			{
			  pthread_cond_wait (&condition1, &mutexAccesNbcamions);	/* On attend que la condition soit remplie */
			}
		    }
		  pthread_mutex_unlock (&mutexAccesNbcamions);
		  cam.numliste = 1;
		  dechargement_peniche_camion (cam);
		}
	      sem_wait (&mutexAccesQuai);	//attente signal acces quai
		affichage();
	      printf ("\nLiberation du quai n°1 occupe par la peniche %d...\n",
		      id);
		usleep (1000000);
	      quai.stat[0] = 0;
	      quai.nbquai++;
	      sem_post (&mutexAccesQuai);	//emission signal acces quai
	      sem_post (&mutexLiberationQuai);	//emission signal acces liberation quai
	      pthread_exit (NULL);
	    }
	  else
	    {
		affichage();
		printf ("\nOccupation du quai n°2 avec la peniche %d...\n", id);
	     usleep (1000000);
		 quai.stat[1] = 1;
	      sem_post (&mutexAccesQuai);	//emission signal acces quai
	      usleep(1000000);
	      c.numtrain = 1;
	      if (Ttrain[1].dispo)
		{
		  dechargement_peniche_train (c);
		}
	      else
		{
		  pthread_mutex_lock (&mutexAccesNbcamions);
		  if (nbcamions2 == 0)
		    {
		      while (nbcamions2 == 0)
			{
			  pthread_cond_wait (&condition2, &mutexAccesNbcamions);	/* On attend que la condition soit remplie */
			}
		    }
		  pthread_mutex_unlock (&mutexAccesNbcamions);
		  cam.numliste = 2;
		  dechargement_peniche_camion (cam);
		}
	      sem_wait (&mutexAccesQuai);	//attente signal acces quai
		affichage();
	      printf ("\nLiberation du quai n°2 occupe avec la peniche %d...\n",
		      id);
		usleep (1000000);
	      quai.nbquai++;
		quai.stat[1] = 0;
	      sem_post (&mutexAccesQuai);	//emission signal acces quai
	      sem_post (&mutexLiberationQuai);	//emission signal acces liberation quai
	      pthread_exit (NULL);
	    }
	}
	}
	else
	{
	//Verifier qu 'au moins un des quais est disponible
      sem_wait (&mutexAccesQuai);
      //attente signal acces quai
        affichage();
      printf
        ("\nVerification disponibilite d'un quai avec la peniche ...%d\n",id);
        usleep (1000000);
      if (quai.nbquai == 0)
        {
          sem_post (&mutexAccesQuai);   //emission signal acces quai
                affichage();
          printf
            ("\nAucun quai disponible, attente disponibilite avec la peniche %d...\n",
             id);
		usleep (1000000);
          sem_wait (&mutexLiberationQuai);      //attente signal liberation quai
        }
      else
        {
          quai.nbquai--;
          if (!quai.stat[0])    //on est au quai 1
            {
		affichage();
            printf ("\nOccupation du quai n°1 avec la peniche %d...\n", id);
            usleep (1000000);
              quai.stat[0] = 1; // on met le booléen du quai 1 à occupé
              sem_post (&mutexAccesQuai);       //emission signal acces quai
              usleep(1000000);
              c.numtrain = 0;
              if (!Ttrain[0].dispo)
                {
                  chargement_train_peniche (c);
                }
              else
                {
                  pthread_mutex_lock (&mutexAccesNbcamions);
                  if (nbcamions1 == 0)
                    {
                     while (nbcamions1 == 0)
                        {
                          pthread_cond_wait (&condition1, &mutexAccesNbcamions);        /* On attend que la condition soit remplie */
                        }
                    }
                  pthread_mutex_unlock (&mutexAccesNbcamions);
                  cam.numliste = 1;
                 chargement_camion_peniche (cam);
                }
              sem_wait (&mutexAccesQuai);       //attente signal acces quai
                affichage();
              printf ("\nLiberation du quai n°1 occupe par la peniche %d...\n",
		         id);
                usleep (1000000);
              quai.stat[0] = 0;
              quai.nbquai++;
              sem_post (&mutexAccesQuai);       //emission signal acces quai
              sem_post (&mutexLiberationQuai);  //emission signal acces liberation quai
              pthread_exit (NULL);
            }
          else
            {
		affichage();
                printf ("\nOccupation du quai n°2 avec la peniche %d...\n", id);
             usleep (1000000);
                 quai.stat[1] = 1;
              sem_post (&mutexAccesQuai);       //emission signal acces quai
              usleep(1000000);
              c.numtrain = 1;
              if (!Ttrain[1].dispo)
                {
                  chargement_train_peniche (c);
                }
              else
                {
                  pthread_mutex_lock (&mutexAccesNbcamions);
                  if (nbcamions2 == 0)
                    {
                      while (nbcamions2 == 0)
                        {
                          pthread_cond_wait (&condition2, &mutexAccesNbcamions);        /* On attend que la condition soit remplie */
                        }
                    }
                  pthread_mutex_unlock (&mutexAccesNbcamions);
                  cam.numliste = 2;
                  chargement_camion_peniche (cam);
                }
              sem_wait (&mutexAccesQuai);       //attente signal acces quai
                affichage();
              printf ("\nLiberation du quai n°2 occupe avec la peniche %d...\n",
                      id);
                usleep (1000000);
              quai.nbquai++;
                quai.stat[1] = 0;
              sem_post (&mutexAccesQuai);       //emission signal acces quai
              sem_post (&mutexLiberationQuai);  //emission signal acces liberation quai
              pthread_exit (NULL);
            }
	}
    }
}
}

//fonction affichage de peniches
void affichage_peniches()
{
  int i,j;
  for(i=0;i<23;i++)
  {
    j=0;
    printf("\nID:%d Place1: %d Place2: %d",Tpeniche[i].ID,Tpeniche[i].place[j],Tpeniche[i].place[j+1]);
  }

}

//fonction affichage de train
void affichage_trains()
{
  printf("\n TRAIN 1 ID: %d Dispo %d			    TRAIN 2 ID: %d Dispo %d",Ttrain[0].ID,Ttrain[0].dispo,Ttrain[1].ID,Ttrain[1].dispo);
  int i;
  for(i=0;i<6;i++)
  {
    printf("\n Wagon %d: %d 	                                    Wagon %d: %d",i+1,Ttrain[0].wagon[i],i+1,Ttrain[1].wagon[i]);
  }

}

//Fonction affichage de camions
void affichage_camions(listecamions elt1, listecamions elt2)
{
  listecamions L1,L2;
  L1=elt1;
  L2=elt2;
    printf("\nQuai 1:                                Quai 2:");
    while(L1!=NULL && L2!=NULL)
    {
      printf("\nID: %d  Etat: %d	               ID: %d  Etat: %d",(L1->c).ID,(L1->c).libre,(L2->c).ID,(L2->c).libre);
      L1=L1->next;
      L2=L2->next;
    }
    if(L1==NULL)
    {
      while(L2!=NULL)
      {
        printf("\n                                       ID: %d  Etat: %d",(L2->c).ID,(L2->c).libre);
	L2=L2->next;
      }
    }
    else
    {
      while(L1!=NULL)
      {
        printf("\nID: %d  Etat: %d",(L1->c).ID,(L1->c).libre);
        L1=L1->next;
      }
    }

}



void affichage()
{
  system("clear");
  system("clear");
  printf ("\n\n Affichage");
  affichage_camions (L1, L2);
  printf ("\n\n Affichage Peniches");
  affichage_peniches ();
  printf ("\n\n AFFICHAGE TRAIN");
  printf ("\n");
  affichage_trains ();
  printf ("\n");

}
