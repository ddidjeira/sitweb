#include <stdio.h>
#define VRAI 1
#define FAUX 0

//Declaration du type booléen
typedef int BOOL;

//Declaration du type quai
typedef struct
{
  int nbquai;
  BOOL stat[2];
} port;
//Déclaration du type péniche composé de l'id de la peniche qui est unique et de d'un tableau de 2 Booléens permettant de savoir sil y a un container ou pas.
typedef struct
{
  int ID;
  BOOL place[2];
  int charger;
} peniche;

//Declaration du type train qui composé du nombre de wagons limités.Nous prendrons dans notre cas 6 correspondant aux conteneurs des 3 peniches
typedef struct
{
  int ID;
  BOOL dispo;
  BOOL wagon[6];
} train;

//Declaration du type train qui composé du nombre de wagons limités.Nous prendrons dans notre cas 6 correspondant aux conteneurs des 3 peniches
typedef struct
{
  int ID;
  BOOL libre;
} camion;
//declaration d'une structure chargement_train qui est composé d'une peniche et d'un train
typedef struct
{
  int numpeniche;
  int numtrain;
} chargement_train;
typedef struct elem
{
  camion c;
  struct elem *next;
} element;
typedef element *listecamions;

typedef struct
{
  int numpeniche;
  int numliste;
} chargement_camion;
//Declaration du thread portique qui va prendre un conteneur et le mettre sur un train ou sur un camion si n'y a plus de train
void *thread_portique (void);
void *thread_chargement (void);
void *thread_dechargement (void);

//Déclaration d'un tableau correspondant à la zone d'amarrage des péniches
peniche zone[2];

//Fonction de déchargement de la peniche sur un train
void dechargement_peniche_train (chargement_train c);

//Fonction de déchargement de la peniche sur un camion
void dechargement_peniche_camion (chargement_camion cam);

//Fonction de déchargement de la peniche sur un train
void chargement_train_peniche (chargement_train c);

//Fonction de déchargement de la peniche sur un camion
void chargement_camion_peniche (chargement_camion cam);

// Déclaration des traitants de signaux
void traitantSIGINT (int num);

void traitantSIGTSTP (int num);

//fonction permettant de compter le nombre de camions
int comptercam (listecamions L);

//Fonction qui permet d'ajouter un camions à la liste
listecamions ajouter (listecamions L, camion elt);

//Declarations de prototypes des fonctions utiles
void initialisation_donnees_dechargement ();	// initialise nos données de simulation dans le cas où on decharge les peniches
void initialisation_donnees_chargement (); // initialise nos données dans le cas où on charges les peniches
void initialisation_semaphores ();	// initialise les sémaphores créées pour la synchronisation
void destruction_semaphores ();	// détruit les sémaphores créées pour la synchronisation
int initialisation_peniche (char *penicheFileName);	//initialise les peniches
listecamions initialisation_camions (listecamions L, char *camionFileName);	// initialise les camions
void initialisation_train1 (char *train1FileName);	// initialise les trains
void initialisation_train2 (char *train2FileName);
int x,rep;
int nbcamions1;                 //nombre de camions pour la file lié au quai 1
int nbcamions2;                 //nombre de camions pour la file lié au quai 2
listecamions L1;                //liste de camions affiliés au quai 1
listecamions L2;                //liste de camions affiliés au quai 1
port quai;
train Ttrain[2];                //tableau de train
peniche Tpeniche[23];           //tableau de peniches
void affichage_peniches();
void affichage_trains();
void affichage_camions(listecamions elt1, listecamions elt2);
void * ammarrer (void *data);
void erreur(const char *msg);
void affichage();
